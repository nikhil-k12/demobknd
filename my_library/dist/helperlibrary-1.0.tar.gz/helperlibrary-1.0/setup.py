from setuptools import setup

setup(
    name='helperlibrary',
    version='1.0',
    packages=['helperlibrary'],
    install_requires=[
        'boto3'
    ],
)
